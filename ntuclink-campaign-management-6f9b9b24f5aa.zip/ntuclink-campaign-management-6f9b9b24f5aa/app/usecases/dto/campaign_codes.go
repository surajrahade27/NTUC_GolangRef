package dto

// CampaignCodeDTO ..
// swagger:response CampaignCodeDTO
type CampaignCodeDTO struct {
	StatusCode  int64  `json:"status_code"`
	StatusValue string `json:"status_value"`
}
