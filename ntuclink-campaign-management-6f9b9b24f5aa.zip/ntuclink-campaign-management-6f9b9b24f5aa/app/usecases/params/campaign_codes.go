package params

// CampaignCodeForm ..
// swagger:model CampaignCodeForm
type CampaignCodeForm struct {
	StatusCode  int64  `json:"status_code"`
	StatusValue string `json:"status_value"`
}
