package mysql

type Tabler interface {
	TableName() string
}
